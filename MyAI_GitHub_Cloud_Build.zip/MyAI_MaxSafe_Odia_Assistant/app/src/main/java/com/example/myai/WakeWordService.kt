package com.example.myai

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Best-effort wake phrase listener while the app has explicitly started this
 * microphone foreground service. Android's general SpeechRecognizer is not a
 * true low-power always-on hotword engine; OEM/OS may stop it or limit it.
 */
class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListening()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification())
        beginListening()
        return START_STICKY
    }

    private fun beginListening() {
        if (listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf(); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                listening = false
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty().lowercase(Locale.ROOT)
                if (spoken.contains("hey my ai") || spoken.contains("ହେ ମାଇ ଏଆଇ")) {
                    val open = packageManager.getLaunchIntentForPackage(packageName)
                    open?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    // Android may block launching UI from the background. Notification remains available.
                    if (open != null) {
                        val pending = PendingIntent.getActivity(
                            this@WakeWordService, 11, open,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        val n = NotificationCompat.Builder(this@WakeWordService, CHANNEL_ID)
                            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                            .setContentTitle("My AI ଆପଣଙ୍କୁ ଶୁଣିଲା")
                            .setContentText("My AI ଖୋଲିବାକୁ ଟାପ୍ କରନ୍ତୁ")
                            .setContentIntent(pending).setAutoCancel(true).build()
                        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                            .notify(NOTIFICATION_ID + 1, n)
                    }
                }
                restartSoon()
            }
            override fun onError(error: Int) { listening = false; restartSoon() }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { listening = true; recognizer?.startListening(intent) }
        catch (_: Exception) { listening = false; restartSoon() }
    }

    private fun restartSoon() {
        if (restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (recognizer != null) beginListening()
        }, 1200)
    }

    private fun stopListening() {
        recognizer?.cancel(); recognizer?.destroy()
        recognizer = null; listening = false
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("My AI wake word ଚାଲୁ ଅଛି")
            .setContentText("“Hey My AI” କୁହନ୍ତୁ। ବନ୍ଦ କରିବାକୁ My AI ଆପ୍ ଖୋଲନ୍ତୁ।")
            .setOngoing(true)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "My AI microphone",
                NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null

    companion object {
        const val ACTION_START = "com.example.myai.START_WAKE"
        const val ACTION_STOP = "com.example.myai.STOP_WAKE"
        private const val CHANNEL_ID = "my_ai_wake_channel"
        private const val NOTIFICATION_ID = 42
    }
}
