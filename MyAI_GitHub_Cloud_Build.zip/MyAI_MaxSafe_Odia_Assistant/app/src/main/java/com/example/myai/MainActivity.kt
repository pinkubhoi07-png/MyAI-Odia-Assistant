package com.example.myai

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val CHAT_URL = "https://YOUR-SERVER-DOMAIN.example.com/chat"

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: android.speech.SpeechRecognizer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.RECORD_AUDIO] == true) {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_START))
            Toast.makeText(this, "Hey My AI wake listening ଆରମ୍ଭ ହେଲା", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            MyAiScreen(
                onStartWake = { enableWakeWord() },
                onStopWake = { stopService(Intent(this, WakeWordService::class.java)) },
                onMic = { listenOnce { command -> handleCommand(command) } },
                onSend = { question, reply, error -> askAi(question, reply, error) },
                onSpeak = { speak(it) }
            )
        }
    }

    private fun enableWakeWord() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_START))
        } else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun listenOnce(onText: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)); return
        }
        val r = recognizer ?: run {
            Toast.makeText(this, "ଏହି ଫୋନରେ Speech Recognition ମିଳୁନାହିଁ", Toast.LENGTH_LONG).show()
            return
        }
        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "or-IN")
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "or-IN")
        }
        r.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onResults(b: Bundle?) {
                b?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.let(onText)
            }
            override fun onError(error: Int) { }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })
        r.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val text = raw.lowercase(Locale.ROOT)
        when {
            "ଟର୍ଚ୍ଚ" in text || "flashlight" in text || "torch" in text ->
                Toast.makeText(this, "ଟର୍ଚ୍ଚ ନିୟନ୍ତ୍ରଣ ପାଇଁ ଏହି ଭର୍ସନରେ Camera flash permission flow ଆବଶ୍ୟକ।", Toast.LENGTH_LONG).show()
            "କ୍ୟାମେରା" in text || "camera" in text ->
                launchIntent(android.content.Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))
            "ଆଲାର୍ମ" in text || "alarm" in text ->
                launchIntent(android.content.Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_SKIP_UI, false))
            "wifi" in text || "ୱାଇଫାଇ" in text ->
                launchIntent(android.content.Intent(Settings.Panel.ACTION_WIFI))
            "bluetooth" in text || "ବ୍ଲୁଟୁଥ" in text ->
                launchIntent(android.content.Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "ଭଲ୍ୟୁମ୍ ବଢ଼ା" in text || "volume up" in text -> {
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                speak("ଭଲ୍ୟୁମ୍ ବଢ଼ାଇଦେଲି")
            }
            "ଭଲ୍ୟୁମ୍ କମା" in text || "volume down" in text -> {
                (getSystemService(AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                speak("ଭଲ୍ୟୁମ୍ କମାଇଦେଲି")
            }
            "କଲ୍" in text || "call" in text ->
                launchIntent(android.content.Intent(android.content.Intent.ACTION_DIAL))
            "ମେସେଜ୍" in text || "sms" in text ->
                launchIntent(android.content.Intent(android.content.Intent.ACTION_SENDTO, Uri.parse("smsto:")))
            "ସେଟିଂ" in text || "settings" in text ->
                launchIntent(android.content.Intent(Settings.ACTION_SETTINGS))
            "youtube" in text ->
                openPackage("com.google.android.youtube")
            "whatsapp" in text ->
                openPackage("com.whatsapp")
            else -> askAi(raw, { speak(it); Toast.makeText(this, it, Toast.LENGTH_LONG).show() },
                { Toast.makeText(this, it, Toast.LENGTH_LONG).show() })
        }
    }

    private fun launchIntent(intent: android.content.Intent) {
        try { startActivity(intent) }
        catch (_: Exception) { Toast.makeText(this, "ଏହି ସୁବିଧା ଫୋନରେ ମିଳୁନାହିଁ", Toast.LENGTH_SHORT).show() }
    }

    private fun openPackage(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "App install ହୋଇନାହିଁ", Toast.LENGTH_SHORT).show()
    }

    private fun askAi(question: String, onReply: (String) -> Unit, onError: (String) -> Unit) {
        Thread {
            try {
                val body = JSONObject().put("message", question).toString()
                    .toRequestBody("application/json".toMediaType())
                val req = Request.Builder().url(CHAT_URL).post(body).build()
                OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
                    .newCall(req).execute().use { response ->
                        val data = response.body?.string().orEmpty()
                        if (!response.isSuccessful) throw Exception("Server error ${response.code}")
                        val reply = JSONObject(data).optString("reply")
                        runOnUiThread { if (reply.isNotBlank()) onReply(reply) else onError("ଉତ୍ତର ମିଳିଲା ନାହିଁ") }
                    }
            } catch (e: Exception) {
                runOnUiThread { onError("AI ସଂଯୋଗ ହେଲା ନାହିଁ: ${e.message}") }
            }
        }.start()
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myai_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("or", "IN"))
            val female = tts?.voices?.firstOrNull {
                it.locale.language == "or" &&
                    (it.name.contains("female", true) || it.features?.contains("female") == true)
            }
            if (female != null) tts?.voice = female
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}

private data class ChatMessage(val text: String, val user: Boolean)

@Composable
private fun MyAiScreen(
    onStartWake: () -> Unit,
    onStopWake: () -> Unit,
    onMic: () -> Unit,
    onSend: (String, (String) -> Unit, (String) -> Unit) -> Unit,
    onSpeak: (String) -> Unit
) {
    var entry by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatMessage("ନମସ୍କାର! ମୁଁ My AI। ଓଡ଼ିଆରେ କଥା ହୁଅନ୍ତୁ।", false)) }

    Column(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF10172A), Color(0xFF21113D))).padding(18.dp)
    )) {
        Text("My AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("ଓଡ଼ିଆ Voice Assistant", color = Color(0xFFC9B8F5))
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onStartWake, modifier = Modifier.weight(1f)) { Text("Hey My AI ON") }
            OutlinedButton(onClick = onStopWake, modifier = Modifier.weight(1f)) { Text("OFF") }
        }
        Text("Wake listening ଚାଲୁ ଥିଲେ microphone notification ଦେଖାଯିବ।",
            color = Color(0xFFCAC5D8), fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement =
                    if (m.user) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (m.user) Color(0xFF6245B8) else Color(0xFF29334B),
                        shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(m.text, color = Color.White)
                            if (!m.user) TextButton(onClick = { onSpeak(m.text) }) {
                                Icon(Icons.Default.VolumeUp, null, tint = Color.White)
                                Text(" ଶୁଣନ୍ତୁ", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = Color(0xFFFFB4AB), fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(entry, { entry = it }, Modifier.weight(1f),
                placeholder = { Text("ଓଡ଼ିଆରେ ଲେଖନ୍ତୁ") }, shape = RoundedCornerShape(22.dp))
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, "Voice", tint = Color.White) }
            IconButton(onClick = {
                val q = entry.trim()
                if (q.isNotEmpty() && !busy) {
                    entry = ""; messages.add(ChatMessage(q, true)); busy = true; error = ""
                    onSend(q, { messages.add(ChatMessage(it, false)); busy = false; onSpeak(it) },
                        { error = it; busy = false })
                }
            }, enabled = !busy) { Icon(Icons.Default.Send, "Send", tint = Color.White) }
        }
    }
}
