# My AI v2 — Maximum Safe Access (Odia)

## ଏହି ଭର୍ସନରେ
- ଓଡ଼ିଆ AI chat (API backend ଦ୍ୱାରା)
- ଓଡ଼ିଆ TTS voice ଚୟନ ଚେଷ୍ଟା; female voice ଫୋନର TTS engine ଉପରେ ନିର୍ଭର
- ମାଇକ୍‌ରେ one-shot voice input
- `Hey My AI` best-effort wake phrase listener ଏକ foreground microphone service ଭାବେ
- Camera app, Alarm UI, Wi-Fi panel, Bluetooth settings, general settings, dialer, SMS composer, YouTube/WhatsApp ଖୋଲିବା
- Volume up/down

## ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ wake-word ସୀମା
Android ର standard `SpeechRecognizer` କୌଣସି dedicated always-on hotword engine ନୁହେଁ। ଏହି sample ରେ user ନିଜେ app ରେ ON ଦବାଇ foreground microphone service ଆରମ୍ଭ କରେ; notification ସବୁବେଳେ ଦେଖାଯିବ। OS/OEM ଏହାକୁ ବନ୍ଦ କରିପାରେ, battery ଅଧିକ ଖର୍ଚ୍ଚ ହୋଇପାରେ, network recognition service ଆବଶ୍ୟକ ହୋଇପାରେ। Wake phrase ଚିହ୍ନଟ ହେଲେ background ରୁ app ଖୋଲିବା Android ରେ ବ୍ଲକ୍ ହୋଇପାରେ; ସେଥିପାଇଁ notification ଦିଆଯାଏ। ଏହା lock-screen ରେ Google Assistant ପରି ନିଶ୍ଚିତ hotword ନୁହେଁ।

## ଫୋନ୍‌ର ନିୟନ୍ତ୍ରଣ / ଅନୁମତି
- Call command କେବଳ dialer ଖୋଲେ; call କରିବା ପୂର୍ବରୁ ଆପଣଙ୍କୁ number ବାଛି Call ଦବାଇବାକୁ ପଡ଼ିବ।
- SMS command message composer ଖୋଲେ; ଆପଣ ପଢ଼ି Send ଦବାଇବେ।
- Wi-Fi panel ଓ Bluetooth settings ଖୋଲେ; system UI ରେ ଆପଣ ନିଜେ confirm କରନ୍ତୁ।
- App ଅନ୍ୟ app ର private data, OTP, password, bank data କିମ୍ବା protected settings ପଢ଼େ ନାହିଁ।
- ଏହି sample ରେ Accessibility Service ନାହିଁ। ଏହାକୁ ଯୋଡ଼ିଲେ user-initiated, visible, narrow UI automation ଭାବେ ଅଲଗା design ଓ Play policy review ଦରକାର।
- Torch command ଏହି starter ରେ placeholder; device camera flash API ଓ CAMERA permission ସହିତ ଅଲଗା implementation ଦରକାର।

## Backend setup
1. Node.js 20+ install କରନ୍ତୁ।
2. `backend/.env.example` କୁ `.env` କରନ୍ତୁ।
3. `.env` ରେ API key ଦିଅନ୍ତୁ; key କେବେ Android app ଭିତରେ ରଖନ୍ତୁ ନାହିଁ।
4. `OPENAI_MODEL` କୁ ଆପଣଙ୍କ API project ରେ ଉପଲବ୍ଧ model ID ରେ set କରନ୍ତୁ।
5. `npm install && npm start`
6. HTTPS hosting ରେ deploy କରନ୍ତୁ।

## Android build
1. Android Studio ରେ project folder ଖୋଲନ୍ତୁ।
2. `MainActivity.kt` ର `CHAT_URL` କୁ backend HTTPS URL କରନ୍ତୁ।
3. Gradle Sync କରନ୍ତୁ।
4. Android 13+ ରେ notification permission ଏବଂ microphone permission ଦିଅନ୍ତୁ।
5. Build → Build Bundle(s) / APK(s) → Build APK(s)।
6. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
7. Share କରିବା ପାଇଁ Generate Signed Bundle / APK ରୁ signed APK ବନାନ୍ତୁ।

## Testing
- ପ୍ରଥମେ app ଖୋଲି “Hey My AI ON” ଦବାନ୍ତୁ।
- Persistent notification ଦେଖାଯାଉଛି କି ଯାଞ୍ଚ କରନ୍ତୁ।
- ଇଂରାଜୀରେ “Hey My AI” କୁହନ୍ତୁ (wake-word recognition ପାଇଁ)।
- App ଖୋଲିବା ପରେ mic button ଦ୍ୱାରା Odia command ଦିଅନ୍ତୁ।
- Odia speech recognition ଓ female Odia TTS ଫୋନର installed speech/TTS engine ରେ ଥିବା ଦରକାର।

## GitHub ରେ ମାଗଣା Cloud Build କରି APK ପାଇବା
1. GitHub ରେ ମାଗଣା account ଖୋଲି `New repository` କରନ୍ତୁ (Public କିମ୍ବା Private)।
2. ZIP ର ଭିତରେ ଥିବା ଏହି project folder ର ସମସ୍ତ ଫାଇଲ୍ repository ର root ରେ upload କରନ୍ତୁ। `.github/workflows/build-apk.yml` ଫାଇଲ୍‌ଟି ମଧ୍ୟ upload ହେବା ଦରକାର।
3. Repository ର `Actions` tab ଖୋଲନ୍ତୁ। `Build My AI APK` workflow ବାଛି `Run workflow` ଦବାନ୍ତୁ।
4. Build ସଫଳ ହେଲେ run ର ତଳେ `Artifacts` ରୁ `MyAI-debug-apk` download କରନ୍ତୁ। ZIP ଖୋଲି `app-debug.apk` install କରନ୍ତୁ।
5. Android ପଚାରିଲେ browser/file manager ପାଇଁ `Install unknown apps` ଅନୁମତି ଦିଅନ୍ତୁ।

ଏହା debug/test APK; Play Store release ପାଇଁ signed release build ଅଲଗା ଭାବେ କରିବାକୁ ପଡ଼ିବ। GitHub Actions ର ମାଗଣା usage limits ଲାଗୁ ହୋଇପାରେ।
