import "dotenv/config";
import express from "express";

const app = express();
app.use(express.json({ limit: "20kb" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message ?? "").trim();
    if (!message) return res.status(400).json({ error: "Message required" });
    if (message.length > 4000) return res.status(413).json({ error: "Message too long" });
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "API key missing" });

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6",
        instructions: "ତୁମେ My AI, ଜଣେ ଭଦ୍ର ଓ ସୁରକ୍ଷିତ ଓଡ଼ିଆ ଭଏସ୍ ସହାୟକ। ସବୁବେଳେ ସରଳ, ସ୍ୱାଭାବିକ ଓଡ଼ିଆରେ ଉତ୍ତର ଦିଅ। ଫୋନ୍‌ର କାମ କରିସାରିଛ ବୋଲି କେବେ କୁହ ନାହିଁ; ଆପ୍‌ରେ ଥିବା କମାଣ୍ଡ ସୁବିଧା କରିପାରିବା କାମ ମାତ୍ର କରେ।",
        input: message
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("AI API returned", upstream.status, data);
      return res.status(502).json({ error: "AI service error" });
    }
    const reply = (data.output ?? []).flatMap(x => x.content ?? [])
      .filter(x => x.type === "output_text").map(x => x.text).join("\n").trim();
    if (!reply) return res.status(502).json({ error: "Empty AI response" });
    res.json({ reply });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Unexpected backend error" });
  }
});

app.listen(Number(process.env.PORT || 3000), () =>
  console.log("My AI backend listening"));
